// Opt-in real-loader smoke test. No window or game process is required.
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#include <vector>

static void require(VkResult result, const char* name) {
    if (result != VK_SUCCESS) {
        std::fprintf(stderr, "%s failed: %d\n", name, result);
        std::exit(1);
    }
}
template <typename T> static T function(PFN_vkVoidFunction fn, const char* name) {
    if (!fn) { std::fprintf(stderr, "missing %s\n", name); std::exit(1); }
    return reinterpret_cast<T>(fn);
}
int main() {
    void* loader = dlopen("libvulkan.so.1", RTLD_NOW | RTLD_LOCAL);
    if (!loader) { std::fprintf(stderr, "%s\n", dlerror()); return 1; }
    auto gipa = reinterpret_cast<PFN_vkGetInstanceProcAddr>(dlsym(loader, "vkGetInstanceProcAddr"));
    if (!gipa) return 1;
#define INSTANCE(name) function<PFN_##name>(gipa(instance, #name), #name)
    VkInstance instance{};
    VkApplicationInfo app{};
    app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.pApplicationName = "depth-probe-loader-smoke";
    app.apiVersion = VK_API_VERSION_1_3;
    const char* layer = "VK_LAYER_depth_probe";
    VkInstanceCreateInfo ci{};
    ci.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    ci.pApplicationInfo = &app;
    ci.enabledLayerCount = 1; ci.ppEnabledLayerNames = &layer;
    require(INSTANCE(vkCreateInstance)(&ci, nullptr, &instance), "vkCreateInstance");
    uint32_t count = 0;
    auto enumerate = INSTANCE(vkEnumeratePhysicalDevices);
    require(enumerate(instance, &count, nullptr), "vkEnumeratePhysicalDevices");
    if (!count) return 1;
    std::vector<VkPhysicalDevice> physicals(count);
    require(enumerate(instance, &count, physicals.data()), "vkEnumeratePhysicalDevices");
    auto physical = physicals.front();
    VkPhysicalDeviceProperties properties{};
    INSTANCE(vkGetPhysicalDeviceProperties)(physical, &properties);
    INSTANCE(vkGetPhysicalDeviceQueueFamilyProperties)(physical, &count, nullptr);
    std::vector<VkQueueFamilyProperties> queues(count);
    INSTANCE(vkGetPhysicalDeviceQueueFamilyProperties)(physical, &count, queues.data());
    uint32_t family = 0;
    while (family < count && !(queues[family].queueFlags & VK_QUEUE_GRAPHICS_BIT)) ++family;
    if (family == count) return 1;
    float priority = 1;
    VkDeviceQueueCreateInfo qi{};
    qi.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
    qi.queueFamilyIndex = family; qi.queueCount = 1; qi.pQueuePriorities = &priority;
    VkDeviceCreateInfo di{};
    di.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    di.queueCreateInfoCount = 1; di.pQueueCreateInfos = &qi;
    VkDevice device{};
    require(INSTANCE(vkCreateDevice)(physical, &di, nullptr, &device), "vkCreateDevice");
    auto gdpa = INSTANCE(vkGetDeviceProcAddr);
#define DEVICE(name) function<PFN_##name>(gdpa(device, #name), #name)
    VkQueue queue{};
    DEVICE(vkGetDeviceQueue)(device, family, 0, &queue);
    VkImageCreateInfo ii{};
    ii.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    ii.imageType = VK_IMAGE_TYPE_2D; ii.format = VK_FORMAT_D24_UNORM_S8_UINT;
    ii.extent = {1920, 1080, 1}; ii.mipLevels = 1; ii.arrayLayers = 1;
    ii.samples = VK_SAMPLE_COUNT_1_BIT; ii.tiling = VK_IMAGE_TILING_OPTIMAL;
    ii.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    VkPhysicalDeviceMemoryProperties memory{};
    INSTANCE(vkGetPhysicalDeviceMemoryProperties)(physical, &memory);
    for (unsigned iteration = 0; iteration < 3; ++iteration) {
        VkImage image{};
        require(DEVICE(vkCreateImage)(device, &ii, nullptr, &image), "vkCreateImage");
        VkMemoryRequirements requirements{};
        DEVICE(vkGetImageMemoryRequirements)(device, image, &requirements);
        uint32_t type = 0;
        while (type < memory.memoryTypeCount && !(requirements.memoryTypeBits & (1u << type))) ++type;
        if (type == memory.memoryTypeCount) return 1;
        VkMemoryAllocateInfo ai{};
        ai.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        ai.allocationSize = requirements.size; ai.memoryTypeIndex = type;
        VkDeviceMemory allocation{};
        require(DEVICE(vkAllocateMemory)(device, &ai, nullptr, &allocation), "vkAllocateMemory");
        require(DEVICE(vkBindImageMemory)(device, image, allocation, 0), "vkBindImageMemory");
        VkImageViewCreateInfo vi{};
        vi.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        vi.image = image; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = ii.format;
        vi.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT | VK_IMAGE_ASPECT_STENCIL_BIT, 0, 1, 0, 1};
        VkImageView view{};
        require(DEVICE(vkCreateImageView)(device, &vi, nullptr, &view), "vkCreateImageView");
        DEVICE(vkDestroyImageView)(device, view, nullptr);
        DEVICE(vkDestroyImage)(device, image, nullptr);
        DEVICE(vkFreeMemory)(device, allocation, nullptr);
    }
    DEVICE(vkDestroyDevice)(device, nullptr);
    INSTANCE(vkDestroyInstance)(instance, nullptr);
    std::printf("PASS: %zu-bit real Vulkan loader, %s, 3 depth image/view lifecycles\n", sizeof(void*) * 8, properties.deviceName);
    dlclose(loader);
}
