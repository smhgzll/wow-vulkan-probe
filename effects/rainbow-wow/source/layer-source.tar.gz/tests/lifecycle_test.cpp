#include "layer_state.hpp"
#include "overlay_renderer.hpp"
#include "heartbeat.hpp"

#include <cmath>
#include <cstdio>
#include <set>
#include <type_traits>

using namespace depth_probe;
namespace {
void check(bool ok, const char* expression, int line) {
    if (!ok) {
        std::fprintf(stderr, "line %d: %s\n", line, expression);
        std::abort();
    }
}
#define CHECK(x) check(bool(x), #x, __LINE__)

template <typename T> T handle(uint64_t n) {
    if constexpr (std::is_pointer_v<T>) return reinterpret_cast<T>(static_cast<uintptr_t>(n));
    else return static_cast<T>(n);
}
template <typename T> uint64_t number(T h) {
    if constexpr (std::is_pointer_v<T>) return reinterpret_cast<uintptr_t>(h);
    else return h;
}

uint64_t nextId = 100;
int operation = 0, failAt = 0, submits = 0;
std::set<uint64_t> live;
std::vector<std::string> order;
VkImage lastDestroyedImage{};
const VkAllocationCallbacks* lastImageAllocator = nullptr;
HeartbeatConstants lastHeartbeat{};
unsigned pushes = 0;

bool fail() { return ++operation == failAt; }
template <typename Info, typename Handle>
VKAPI_ATTR VkResult VKAPI_CALL create(VkDevice, const Info*, const VkAllocationCallbacks*, Handle* out) {
    if (fail()) return VK_ERROR_OUT_OF_DEVICE_MEMORY;
    *out = handle<Handle>(++nextId);
    CHECK(live.insert(nextId).second);
    return VK_SUCCESS;
}
template <typename Handle>
VKAPI_ATTR void VKAPI_CALL destroy(VkDevice, Handle object, const VkAllocationCallbacks*) {
    CHECK(live.erase(number(object)) == 1);
}
VKAPI_ATTR void VKAPI_CALL destroyImage(VkDevice device, VkImage image, const VkAllocationCallbacks* alloc) {
    lastDestroyedImage = image;
    lastImageAllocator = alloc;
    destroy(device, image, alloc);
}
VKAPI_ATTR VkResult VKAPI_CALL createRenderPass(VkDevice device, const VkRenderPassCreateInfo* info,
                                               const VkAllocationCallbacks* alloc, VkRenderPass* out) {
    CHECK(info->pAttachments[0].loadOp == VK_ATTACHMENT_LOAD_OP_LOAD);
    CHECK(info->pAttachments[0].storeOp == VK_ATTACHMENT_STORE_OP_STORE);
    return create(device, info, alloc, out);
}
VKAPI_ATTR VkResult VKAPI_CALL createPipelineLayout(VkDevice device, const VkPipelineLayoutCreateInfo* info,
                                                   const VkAllocationCallbacks* alloc, VkPipelineLayout* out) {
    CHECK(info->pushConstantRangeCount == 1);
    CHECK(info->pPushConstantRanges[0].offset == 0);
    CHECK(info->pPushConstantRanges[0].size == sizeof(HeartbeatConstants));
    CHECK(info->pPushConstantRanges[0].stageFlags == VK_SHADER_STAGE_FRAGMENT_BIT);
    return create(device, info, alloc, out);
}
VKAPI_ATTR VkResult VKAPI_CALL createCommandPool(VkDevice device, const VkCommandPoolCreateInfo* info,
                                               const VkAllocationCallbacks* alloc, VkCommandPool* out) {
    CHECK(info->flags & VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT);
    return create(device, info, alloc, out);
}
VKAPI_ATTR VkResult VKAPI_CALL createPipelines(VkDevice device, VkPipelineCache, uint32_t count,
                                              const VkGraphicsPipelineCreateInfo* info,
                                              const VkAllocationCallbacks* alloc, VkPipeline* out) {
    CHECK(count == 1);
    const auto& blend = info->pColorBlendState->pAttachments[0];
    CHECK(blend.blendEnable == VK_TRUE);
    CHECK(blend.srcColorBlendFactor == VK_BLEND_FACTOR_SRC_ALPHA);
    CHECK(blend.dstColorBlendFactor == VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA);
    return create(device, info, alloc, out);
}
VKAPI_ATTR VkResult VKAPI_CALL allocateSets(VkDevice, const VkDescriptorSetAllocateInfo*, VkDescriptorSet* out) {
    if (fail()) return VK_ERROR_OUT_OF_DEVICE_MEMORY;
    *out = handle<VkDescriptorSet>(++nextId); // owned by pool
    return VK_SUCCESS;
}
VKAPI_ATTR VkResult VKAPI_CALL allocateCommands(VkDevice, const VkCommandBufferAllocateInfo* info, VkCommandBuffer* out) {
    if (fail()) return VK_ERROR_OUT_OF_DEVICE_MEMORY;
    for (uint32_t i = 0; i < info->commandBufferCount; ++i)
        out[i] = handle<VkCommandBuffer>(++nextId); // owned by pool
    return VK_SUCCESS;
}
VKAPI_ATTR VkResult VKAPI_CALL beginCommand(VkCommandBuffer, const VkCommandBufferBeginInfo* info) {
    CHECK(info->flags == VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT);
    CHECK(!order.empty() && order.back() == "idle"); // wait before every re-record
    order.push_back("record");
    return fail() ? VK_ERROR_OUT_OF_HOST_MEMORY : VK_SUCCESS;
}
VKAPI_ATTR VkResult VKAPI_CALL endCommand(VkCommandBuffer) {
    return fail() ? VK_ERROR_OUT_OF_HOST_MEMORY : VK_SUCCESS;
}
VKAPI_ATTR void VKAPI_CALL updateSets(VkDevice, uint32_t count, const VkWriteDescriptorSet* writes,
                                     uint32_t, const VkCopyDescriptorSet*) {
    CHECK(count == 1);
    CHECK(writes[0].pImageInfo->imageLayout == VK_IMAGE_LAYOUT_GENERAL);
}
VKAPI_ATTR void VKAPI_CALL barrier(VkCommandBuffer, VkPipelineStageFlags, VkPipelineStageFlags,
                                   VkDependencyFlags, uint32_t, const VkMemoryBarrier*, uint32_t,
                                   const VkBufferMemoryBarrier*, uint32_t count, const VkImageMemoryBarrier* barriers) {
    CHECK(count == 1);
    const auto& b = barriers[0];
    if (b.newLayout == VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL) {
        CHECK(b.oldLayout == VK_IMAGE_LAYOUT_PRESENT_SRC_KHR);
        CHECK(b.srcAccessMask & VK_ACCESS_MEMORY_WRITE_BIT);
        CHECK(b.dstAccessMask & VK_ACCESS_COLOR_ATTACHMENT_READ_BIT);
        CHECK(b.dstAccessMask & VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT);
    } else if (b.newLayout == VK_IMAGE_LAYOUT_GENERAL) {
        CHECK(b.oldLayout == VK_IMAGE_LAYOUT_GENERAL);
        CHECK(b.subresourceRange.aspectMask == (VK_IMAGE_ASPECT_DEPTH_BIT | VK_IMAGE_ASPECT_STENCIL_BIT));
    }
}
VKAPI_ATTR void VKAPI_CALL beginPass(VkCommandBuffer, const VkRenderPassBeginInfo*, VkSubpassContents) {}
VKAPI_ATTR void VKAPI_CALL endPass(VkCommandBuffer) {}
VKAPI_ATTR void VKAPI_CALL bindPipeline(VkCommandBuffer, VkPipelineBindPoint, VkPipeline) {}
VKAPI_ATTR void VKAPI_CALL bindSets(VkCommandBuffer, VkPipelineBindPoint, VkPipelineLayout,
                                  uint32_t, uint32_t, const VkDescriptorSet*, uint32_t, const uint32_t*) {}
VKAPI_ATTR void VKAPI_CALL pushConstants(VkCommandBuffer, VkPipelineLayout, VkShaderStageFlags stages,
                                       uint32_t offset, uint32_t size, const void* values) {
    CHECK(stages == VK_SHADER_STAGE_FRAGMENT_BIT && offset == 0 && size == sizeof(HeartbeatConstants));
    std::memcpy(&lastHeartbeat, values, size);
    CHECK(std::isfinite(lastHeartbeat.phase) && lastHeartbeat.phase >= 0 && lastHeartbeat.phase <= 1);
    CHECK(lastHeartbeat.strength == 1.0f);
    CHECK(std::abs(lastHeartbeat.aspectRatio - 1920.0f / 1080.0f) < 0.00001f);
    ++pushes;
    order.push_back("push");
}
VKAPI_ATTR void VKAPI_CALL draw(VkCommandBuffer, uint32_t vertices, uint32_t, uint32_t, uint32_t) {
    CHECK(vertices == 3);
}
VKAPI_ATTR VkResult VKAPI_CALL queueIdle(VkQueue) { order.push_back("idle"); return VK_SUCCESS; }
VKAPI_ATTR VkResult VKAPI_CALL deviceIdle(VkDevice) { return VK_SUCCESS; }
VKAPI_ATTR VkResult VKAPI_CALL submit(VkQueue, uint32_t count, const VkSubmitInfo* info, VkFence fence) {
    CHECK(count == 1 && info->commandBufferCount == 1);
    CHECK(info->waitSemaphoreCount == 0 && info->signalSemaphoreCount == 0 && fence == VkFence{});
    ++submits;
    order.push_back("submit");
    return VK_SUCCESS;
}
VKAPI_ATTR VkResult VKAPI_CALL setLoaderData(VkDevice, void*) {
    return fail() ? VK_ERROR_OUT_OF_HOST_MEMORY : VK_SUCCESS;
}
VKAPI_ATTR void VKAPI_CALL sentinel() {}
VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL gdpa(VkDevice, const char* name) {
#define MAP(n, ...) if (!std::strcmp(name, "vk" #n)) return reinterpret_cast<PFN_vkVoidFunction>(__VA_ARGS__)
    MAP(CreateSampler, create<VkSamplerCreateInfo, VkSampler>);
    MAP(DestroySampler, destroy<VkSampler>);
    MAP(CreateDescriptorSetLayout, create<VkDescriptorSetLayoutCreateInfo, VkDescriptorSetLayout>);
    MAP(DestroyDescriptorSetLayout, destroy<VkDescriptorSetLayout>);
    MAP(CreatePipelineLayout, createPipelineLayout);
    MAP(DestroyPipelineLayout, destroy<VkPipelineLayout>);
    MAP(CreateRenderPass, createRenderPass);
    MAP(DestroyRenderPass, destroy<VkRenderPass>);
    MAP(CreateShaderModule, create<VkShaderModuleCreateInfo, VkShaderModule>);
    MAP(DestroyShaderModule, destroy<VkShaderModule>);
    MAP(CreateGraphicsPipelines, createPipelines);
    MAP(DestroyPipeline, destroy<VkPipeline>);
    MAP(CreateDescriptorPool, create<VkDescriptorPoolCreateInfo, VkDescriptorPool>);
    MAP(DestroyDescriptorPool, destroy<VkDescriptorPool>);
    MAP(AllocateDescriptorSets, allocateSets);
    MAP(UpdateDescriptorSets, updateSets);
    MAP(CreateImageView, create<VkImageViewCreateInfo, VkImageView>);
    MAP(DestroyImageView, destroy<VkImageView>);
    MAP(CreateFramebuffer, create<VkFramebufferCreateInfo, VkFramebuffer>);
    MAP(DestroyFramebuffer, destroy<VkFramebuffer>);
    MAP(CreateCommandPool, createCommandPool);
    MAP(DestroyCommandPool, destroy<VkCommandPool>);
    MAP(AllocateCommandBuffers, allocateCommands);
    MAP(BeginCommandBuffer, beginCommand);
    MAP(EndCommandBuffer, endCommand);
    MAP(CmdPipelineBarrier, barrier);
    MAP(CmdBeginRenderPass, beginPass);
    MAP(CmdEndRenderPass, endPass);
    MAP(CmdBindPipeline, bindPipeline);
    MAP(CmdBindDescriptorSets, bindSets);
    MAP(CmdPushConstants, pushConstants);
    MAP(CmdDraw, draw);
    MAP(QueueSubmit, submit);
    MAP(QueueWaitIdle, queueIdle);
    MAP(DeviceWaitIdle, deviceIdle);
    MAP(TestUnknownExtension, sentinel);
#undef MAP
    return nullptr;
}
VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL gipa(VkInstance, const char* name) { return gdpa({}, name); }
VKAPI_ATTR void VKAPI_CALL destroyDevice(VkDevice, const VkAllocationCallbacks*) { order.push_back("destroyDevice"); }

struct Dispatchable { void* dispatch; } deviceObject{&deviceObject}, otherDeviceObject{&otherDeviceObject};
VkDevice device = reinterpret_cast<VkDevice>(&deviceObject);
VkDevice otherDevice = reinterpret_cast<VkDevice>(&otherDeviceObject);
VkQueue queue = reinterpret_cast<VkQueue>(&deviceObject);
VkSwapchainKHR swapchain = handle<VkSwapchainKHR>(55);

DeviceData deviceData() {
    DeviceData data{};
    data.device = device;
    data.next_gdpa = gdpa;
    data.set_device_loader_data = setLoaderData;
    data.next_create_image = create<VkImageCreateInfo, VkImage>;
    data.next_create_image_view = create<VkImageViewCreateInfo, VkImageView>;
    data.next_destroy_image = destroyImage;
    data.next_destroy_image_view = destroy<VkImageView>;
    data.next_destroy_device = destroyDevice;
    return data;
}
void seedSwapchain() {
    SwapchainInfo sc{};
    sc.width = 1920; sc.height = 1080; sc.format = VK_FORMAT_B8G8R8A8_UNORM;
    sc.images = {handle<VkImage>(10), handle<VkImage>(11), handle<VkImage>(12)};
    g_swapchains[{device, 55}] = sc;
}
VkImage makeDepth() {
    VkImageCreateInfo info{};
    info.extent = {1920, 1080, 1}; info.format = VK_FORMAT_D24_UNORM_S8_UINT;
    info.samples = VK_SAMPLE_COUNT_1_BIT; info.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    VkImage image{};
    CHECK(vkCreateImage(device, &info, nullptr, &image) == VK_SUCCESS);
    VkImageViewCreateInfo vi{};
    vi.image = image; vi.format = info.format; vi.subresourceRange.aspectMask = VK_IMAGE_ASPECT_DEPTH_BIT | VK_IMAGE_ASPECT_STENCIL_BIT;
    VkImageView appView{};
    CHECK(vkCreateImageView(device, &vi, nullptr, &appView) == VK_SUCCESS);
    destroy(device, appView, nullptr); // application's view; layer's view stays alive
    CHECK(g_custom_depth_views.count({device, number(image)}) == 1);
    return image;
}
bool present(const DeviceData& data) {
    uint32_t index = 0;
    VkPresentInfoKHR info{};
    info.swapchainCount = 1; info.pSwapchains = &swapchain; info.pImageIndices = &index;
    return depth_overlay_present(data, queue, &info, 1);
}
} // namespace

int main() {
    setenv("DEPTH_PROBE_LAYER_LOG", "/tmp/depth-probe-lifecycle-test.log", 1);
    unsetenv("DEPTH_PROBE_HEARTBEAT");
    unsetenv("DEPTH_PROBE_HEARTBEAT_BPM");
    unsetenv("DEPTH_PROBE_HEARTBEAT_STRENGTH");
    auto config = read_heartbeat_config();
    CHECK(config.enabled && config.bpm == 72 && config.strength == 1);
    // Tempo is measured in real seconds and preserves precision after long sessions.
    CHECK(std::abs(heartbeat_at(config, 0.25, 1920, 1080).phase - 0.30f) < 0.00001f);
    CHECK(std::abs(heartbeat_at(config, 86400.0 * 30 + 0.25, 1920, 1080).phase - 0.30f) < 0.00001f);
    setenv("DEPTH_PROBE_HEARTBEAT", "0", 1);
    CHECK(heartbeat_at(read_heartbeat_config(), 1.0, 1920, 1080).strength == 0);
    setenv("DEPTH_PROBE_HEARTBEAT_BPM", "nan", 1);
    CHECK(read_heartbeat_config().bpm == 72);
    setenv("DEPTH_PROBE_HEARTBEAT_BPM", "garbage", 1);
    CHECK(read_heartbeat_config().bpm == 72);
    setenv("DEPTH_PROBE_HEARTBEAT_BPM", "10000", 1);
    setenv("DEPTH_PROBE_HEARTBEAT_STRENGTH", "-1", 1);
    CHECK(read_heartbeat_config().bpm == 240 && read_heartbeat_config().strength == 0);
    unsetenv("DEPTH_PROBE_HEARTBEAT");
    unsetenv("DEPTH_PROBE_HEARTBEAT_BPM");
    unsetenv("DEPTH_PROBE_HEARTBEAT_STRENGTH");
    // Older-loader fallback must initialize the dispatch word as documented.
    Dispatchable commandObject{};
    auto fallback = deviceData();
    fallback.set_device_loader_data = nullptr;
    CHECK(initialize_layer_command_buffer(fallback, reinterpret_cast<VkCommandBuffer>(&commandObject)));
    CHECK(commandObject.dispatch == deviceObject.dispatch);
    const auto data = deviceData();
    g_devices[dispatch_key(device)] = data;
    seedSwapchain();
    auto image = makeDepth();
    const auto baseline = live;

    // A first present defines construction + recording failure points.
    operation = 0;
    CHECK(present(data));
    const int failurePoints = operation;
    CHECK(failurePoints > 20);
    CHECK((order == std::vector<std::string>{"idle", "record", "push", "submit", "idle"}));
    const auto resident = live;
    // Repeated present must upload constants again without allocating resources.
    const auto oldPushes = pushes;
    CHECK(present(data));
    CHECK(pushes == oldPushes + 1 && live == resident);
    destroy_depth_overlay_state(data, swapchain);
    CHECK(live == baseline);
    for (int step = 1; step <= failurePoints; ++step) {
        failAt = step; operation = 0; submits = 0;
        CHECK(!present(data));
        CHECK(submits == 0);
        // A recording error keeps the successfully constructed renderer for retry.
        destroy_depth_overlay_state(data, swapchain);
        CHECK(live == baseline);
    }
    failAt = 0;
    // Missing SPIR-V used to leak the sampler, layouts, pool and render pass.
    setenv("DEPTH_PROBE_SHADER_DIR", "/definitely/missing/depth-probe-shaders", 1);
    CHECK(!present(data));
    CHECK(live == baseline);
    setenv("DEPTH_PROBE_SHADER_DIR", DEPTH_PROBE_TEST_SHADER_DIR, 1);
    CHECK(present(data));

    // Begin/end failures while re-recording must skip submit and allow recovery.
    for (int step = 1; step <= 2; ++step) {
        const auto before = live;
        operation = 0; failAt = step; submits = 0;
        CHECK(!present(data));
        CHECK(submits == 0 && live == before);
        failAt = 0;
        CHECK(present(data));
    }

    // The same numeric image handle on another device must remain untouched.
    g_target_depth_images.insert({otherDevice, number(image)});
    g_custom_depth_views[{otherDevice, number(image)}] = handle<VkImageView>(9999);
    VkAllocationCallbacks allocator{};
    vkDestroyImage(device, image, &allocator);
    CHECK(lastDestroyedImage == image && lastImageAllocator == &allocator);
    CHECK(!is_target_depth(device, image));
    CHECK(g_custom_depth_views.count({device, number(image)}) == 0);
    CHECK(is_target_depth(otherDevice, image));
    CHECK(g_custom_depth_views.count({otherDevice, number(image)}) == 1);
    CHECK(live.empty());
    CHECK(!present(data)); // no stale descriptor or command buffer submitted

    // Reuse the destroyed image handle; it must create a fresh custom view.
    nextId = number(image) - 1;
    CHECK(makeDepth() == image);
    CHECK(present(data));
    g_swapchains[{otherDevice, 55}] = {};
    vkDestroyDevice(device, nullptr);
    // The layer owns the extra view/overlay, never the application's image.
    CHECK((live == std::set<uint64_t>{number(image)}));
    live.clear(); // fake driver discards the application-owned image at shutdown

    CHECK(g_devices.empty());
    CHECK(g_swapchains.count({device, 55}) == 0);
    CHECK(g_swapchains.count({otherDevice, 55}) == 1);
    CHECK(g_custom_depth_views.count({otherDevice, number(image)}) == 1);
    CHECK(order.back() == "destroyDevice");

    // Unknown entry points still forward to the next implementation.
    g_devices[dispatch_key(device)] = data;
    CHECK(vkGetDeviceProcAddr(device, "vkTestUnknownExtension") == sentinel);
    CHECK(vkGetDeviceProcAddr(device, "vkNotImplemented") == nullptr);
    CHECK(vkGetDeviceProcAddr(device, "vkDestroyImage") == reinterpret_cast<PFN_vkVoidFunction>(vkDestroyImage));
    VkInstance instance = reinterpret_cast<VkInstance>(&deviceObject);
    InstanceData id{}; id.instance = instance; id.next_gipa = gipa;
    g_instances[dispatch_key(instance)] = id;
    CHECK(vkGetInstanceProcAddr(instance, "vkTestUnknownExtension") == sentinel);
    std::printf("PASS: %d initialization/recording failures, heartbeat timing/config/push constants, re-record recovery, resource cleanup, dispatch forwarding\n", failurePoints);
}
