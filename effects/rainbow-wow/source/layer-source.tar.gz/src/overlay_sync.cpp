#include "overlay_internal.hpp"

namespace depth_probe {

// Existing debug policy: wait, record updated constants, submit, wait.
// This requires rendering and overlay work on the same queue.
bool submit_depth_overlay_debug(const DepthOverlayFns& f, VkQueue queue,
                                const DepthOverlayState& state, uint32_t imageIndex,
                                const HeartbeatConstants& heartbeat) {
    if (!f.queueWaitIdle || !f.queueSubmit)
        return false;

    VkResult r =
        f.queueWaitIdle(queue);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] pre vkQueueWaitIdle");
        return false;
    }

    // Re-record only after completion, never while this command buffer is pending.
    if (!record_depth_overlay_commands(f, state, imageIndex, heartbeat))
        return false;

    VkCommandBuffer cmd = state.commandBuffers[imageIndex];
    VkSubmitInfo submit{};
    submit.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submit.commandBufferCount = 1;
    submit.pCommandBuffers = &cmd;

    r =
        f.queueSubmit(
            queue,
            1,
            &submit,
            VkFence{});

    if (r != VK_SUCCESS) {
        std::ostringstream os;
        os << "[DEPTH-OVERLAY-ERROR] vkQueueSubmit result="
           << static_cast<int>(r);
        log_line(os.str());
        return false;
    }

    r =
        f.queueWaitIdle(queue);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] post vkQueueWaitIdle");
        return false;
    }

    return true;
}

} // namespace depth_probe
