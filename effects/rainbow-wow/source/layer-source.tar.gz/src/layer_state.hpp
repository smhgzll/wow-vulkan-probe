#pragma once

#include <vulkan/vulkan.h>
#include <vulkan/vk_layer.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <mutex>
#include <optional>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <unordered_set>
#include <unistd.h>

#if defined(__GNUC__)
#define LAYER_EXPORT __attribute__((visibility("default")))
#else
#define LAYER_EXPORT
#endif

namespace depth_probe {

constexpr const char* kLayerName = "VK_LAYER_depth_probe";

template <typename T>
void* dispatch_key(T handle) {
    if (handle == VK_NULL_HANDLE) return nullptr;
    return *reinterpret_cast<void**>(handle);
}

struct InstanceData {
    VkInstance instance = VK_NULL_HANDLE;
    PFN_vkGetInstanceProcAddr next_gipa = nullptr;
    PFN_vkDestroyInstance next_destroy_instance = nullptr;
    PFN_vkEnumeratePhysicalDevices next_enumerate_physical_devices = nullptr;
    PFN_vkEnumeratePhysicalDeviceGroups next_enumerate_physical_device_groups = nullptr;
};

struct DeviceData {
    VkDevice device = VkDevice{};
    PFN_vkGetDeviceProcAddr next_gdpa = nullptr;
    PFN_vkSetDeviceLoaderData set_device_loader_data = nullptr;
    PFN_vkDestroyDevice next_destroy_device = nullptr;
    PFN_vkCreateImage next_create_image = nullptr;
    PFN_vkDestroyImage next_destroy_image = nullptr;
    PFN_vkDestroyImageView next_destroy_image_view = nullptr;
    PFN_vkCreateImageView next_create_image_view = nullptr;

    PFN_vkGetDeviceQueue next_get_device_queue = nullptr;
    PFN_vkGetDeviceQueue2 next_get_device_queue2 = nullptr;

    PFN_vkCreateSwapchainKHR next_create_swapchain = nullptr;
    PFN_vkDestroySwapchainKHR next_destroy_swapchain = nullptr;
    PFN_vkGetSwapchainImagesKHR next_get_swapchain_images = nullptr;
    PFN_vkQueuePresentKHR next_queue_present = nullptr;

    PFN_vkCreateCommandPool next_create_command_pool = nullptr;
    PFN_vkDestroyCommandPool next_destroy_command_pool = nullptr;
    PFN_vkAllocateCommandBuffers next_allocate_command_buffers = nullptr;
    PFN_vkBeginCommandBuffer next_begin_command_buffer = nullptr;
    PFN_vkEndCommandBuffer next_end_command_buffer = nullptr;
    PFN_vkQueueSubmit next_queue_submit = nullptr;
    PFN_vkQueueWaitIdle next_queue_wait_idle = nullptr;
    PFN_vkCmdPipelineBarrier next_cmd_pipeline_barrier = nullptr;
    PFN_vkCmdPipelineBarrier2 next_cmd_pipeline_barrier2 = nullptr;
    PFN_vkCmdClearColorImage next_cmd_clear_color_image = nullptr;
};

struct SwapchainInfo {
    uint32_t width = 0;
    uint32_t height = 0;
    VkFormat format = VK_FORMAT_UNDEFINED;
    uint32_t image_count = 0;
    std::vector<VkImage> images;
};

// Non-dispatchable handles need not be unique across logical devices.
struct DeviceHandleKey {
    VkDevice device = VkDevice{};
    uint64_t handle = 0;
    bool operator==(const DeviceHandleKey&) const = default;
};
struct DeviceHandleHash {
    size_t operator()(const DeviceHandleKey& key) const {
        return std::hash<VkDevice>{}(key.device) ^ (std::hash<uint64_t>{}(key.handle) << 1);
    }
};
template <typename T>
using DeviceHandleMap = std::unordered_map<DeviceHandleKey, T, DeviceHandleHash>;

extern std::mutex g_state_mutex;
extern std::unordered_map<void*, InstanceData> g_instances;
extern std::unordered_map<void*, DeviceData> g_devices;
extern std::unordered_map<VkPhysicalDevice, VkInstance> g_physical_to_instance;
extern std::unordered_set<DeviceHandleKey, DeviceHandleHash> g_target_depth_images;
extern DeviceHandleMap<VkImageView> g_custom_depth_views;

extern DeviceHandleMap<SwapchainInfo> g_swapchains;
extern std::atomic<uint64_t> g_present_counter;


template <typename T>
T* find_loader_create_info(const void* pNext, VkStructureType wanted_stype, VkLayerFunction function) {
    struct Header {
        VkStructureType sType;
        const void* pNext;
    };

    const Header* current = reinterpret_cast<const Header*>(pNext);
    while (current) {
        if (current->sType == wanted_stype) {
            auto* info = reinterpret_cast<T*>(const_cast<Header*>(current));
            if (info->function == function) return info;
        }
        current = reinterpret_cast<const Header*>(current->pNext);
    }
    return nullptr;
}

bool initialize_layer_command_buffer(const DeviceData& data, VkCommandBuffer cmd);
std::string log_path();
void log_line(const std::string& text);
uint64_t image_handle_u64(VkImage image);
uint64_t image_view_handle_u64(VkImageView view);
uint64_t queue_handle_u64(VkQueue queue);
uint64_t swapchain_handle_u64(VkSwapchainKHR swapchain);
const char* layout_name(VkImageLayout layout);
bool is_target_depth(VkDevice device, VkImage image);
std::string aspect_string(VkImageAspectFlags aspect);
const char* format_name(VkFormat format);
bool is_depth_or_stencil_format(VkFormat format);
std::string usage_string(VkImageUsageFlags usage);
std::string sample_count_string(VkSampleCountFlagBits samples);
std::string api_version_string(uint32_t version);
std::optional<InstanceData> get_instance_data(VkInstance instance);
std::optional<DeviceData> get_device_data(VkDevice device);
std::optional<VkInstance> instance_for_physical_device(VkPhysicalDevice physicalDevice);
void remember_physical_device(VkInstance instance, VkPhysicalDevice physicalDevice, PFN_vkGetInstanceProcAddr next_gipa);
bool log_all_images();

} // namespace depth_probe
