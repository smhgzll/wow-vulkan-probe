#pragma once
#include "layer_state.hpp"
#include "heartbeat.hpp"

namespace depth_probe {

struct DepthOverlayFns {
    PFN_vkCreateSampler createSampler = nullptr;
    PFN_vkDestroySampler destroySampler = nullptr;
    PFN_vkCreateDescriptorSetLayout createDescriptorSetLayout = nullptr;
    PFN_vkDestroyDescriptorSetLayout destroyDescriptorSetLayout = nullptr;
    PFN_vkCreatePipelineLayout createPipelineLayout = nullptr;
    PFN_vkDestroyPipelineLayout destroyPipelineLayout = nullptr;
    PFN_vkCreateRenderPass createRenderPass = nullptr;
    PFN_vkDestroyRenderPass destroyRenderPass = nullptr;
    PFN_vkCreateShaderModule createShaderModule = nullptr;
    PFN_vkDestroyShaderModule destroyShaderModule = nullptr;
    PFN_vkCreateGraphicsPipelines createGraphicsPipelines = nullptr;
    PFN_vkDestroyPipeline destroyPipeline = nullptr;
    PFN_vkCreateDescriptorPool createDescriptorPool = nullptr;
    PFN_vkDestroyDescriptorPool destroyDescriptorPool = nullptr;
    PFN_vkAllocateDescriptorSets allocateDescriptorSets = nullptr;
    PFN_vkUpdateDescriptorSets updateDescriptorSets = nullptr;
    PFN_vkCreateImageView createImageView = nullptr;
    PFN_vkDestroyImageView destroyImageView = nullptr;
    PFN_vkCreateFramebuffer createFramebuffer = nullptr;
    PFN_vkDestroyFramebuffer destroyFramebuffer = nullptr;
    PFN_vkCreateCommandPool createCommandPool = nullptr;
    PFN_vkDestroyCommandPool destroyCommandPool = nullptr;
    PFN_vkAllocateCommandBuffers allocateCommandBuffers = nullptr;
    PFN_vkBeginCommandBuffer beginCommandBuffer = nullptr;
    PFN_vkEndCommandBuffer endCommandBuffer = nullptr;
    PFN_vkCmdPipelineBarrier cmdPipelineBarrier = nullptr;
    PFN_vkCmdBeginRenderPass cmdBeginRenderPass = nullptr;
    PFN_vkCmdEndRenderPass cmdEndRenderPass = nullptr;
    PFN_vkCmdBindPipeline cmdBindPipeline = nullptr;
    PFN_vkCmdBindDescriptorSets cmdBindDescriptorSets = nullptr;
    PFN_vkCmdPushConstants cmdPushConstants = nullptr;
    PFN_vkCmdDraw cmdDraw = nullptr;
    PFN_vkQueueSubmit queueSubmit = nullptr;
    PFN_vkQueueWaitIdle queueWaitIdle = nullptr;
    PFN_vkDeviceWaitIdle deviceWaitIdle = nullptr;
};

struct DepthOverlayState {
    VkSwapchainKHR swapchain = VkSwapchainKHR{};
    VkImage depthImage = VkImage{};
    VkImageView depthView = VkImageView{};

    uint32_t width = 0;
    uint32_t height = 0;
    VkFormat format = VK_FORMAT_UNDEFINED;

    VkSampler sampler = VkSampler{};
    VkDescriptorSetLayout descriptorSetLayout = VkDescriptorSetLayout{};
    VkPipelineLayout pipelineLayout = VkPipelineLayout{};
    VkRenderPass renderPass = VkRenderPass{};
    VkPipeline pipeline = VkPipeline{};
    VkDescriptorPool descriptorPool = VkDescriptorPool{};
    VkDescriptorSet descriptorSet = VkDescriptorSet{};
    VkCommandPool commandPool = VkCommandPool{};

    std::vector<VkImageView> colorViews;
    std::vector<VkImage> colorImages; // borrowed from the swapchain
    std::vector<VkFramebuffer> framebuffers;
    std::vector<VkCommandBuffer> commandBuffers;
};

DepthOverlayFns load_depth_overlay_fns(const DeviceData& data);
bool depth_overlay_fns_ok(const DepthOverlayFns& f);
bool record_depth_overlay_commands(const DepthOverlayFns& f, const DepthOverlayState& state,
                                   uint32_t imageIndex, const HeartbeatConstants& heartbeat);
bool submit_depth_overlay_debug(const DepthOverlayFns& f, VkQueue queue,
                                const DepthOverlayState& state, uint32_t imageIndex,
                                const HeartbeatConstants& heartbeat);
} // namespace depth_probe
