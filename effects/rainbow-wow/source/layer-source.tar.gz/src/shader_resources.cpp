#include "shader_resources.hpp"
#include <cstdlib>
#include <fstream>

namespace depth_probe {

std::vector<uint32_t> read_spirv_file(const std::string& path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);

    if (!f)
        return {};

    const std::streamsize size = f.tellg();

    if (size <= 0 || (size % 4) != 0)
        return {};

    f.seekg(0, std::ios::beg);

    std::vector<uint32_t> words(
        static_cast<size_t>(size) / sizeof(uint32_t));

    if (!f.read(reinterpret_cast<char*>(words.data()), size))
        return {};

    return words;
}

std::string depth_shader_dir() {
    if (const char* p = std::getenv("DEPTH_PROBE_SHADER_DIR");
        p && *p) {
        return p;
    }

    return "/mnt/Games/Projects/vulkan-depth-probe/shaders";
}

} // namespace depth_probe
