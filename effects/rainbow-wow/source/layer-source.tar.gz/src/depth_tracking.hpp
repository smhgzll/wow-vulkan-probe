#pragma once
#include "layer_state.hpp"

namespace depth_probe {
void destroy_device_depth_views(const DeviceData& data);
} // namespace depth_probe
