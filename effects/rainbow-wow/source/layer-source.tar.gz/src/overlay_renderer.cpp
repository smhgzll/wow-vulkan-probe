#include "overlay_renderer.hpp"
#include "overlay_internal.hpp"
#include "shader_resources.hpp"

namespace depth_probe {

DeviceHandleMap<DepthOverlayState> g_depth_overlay_states;

VkImage depth_image_from_u64(uint64_t value) {
#if VK_USE_64_BIT_PTR_DEFINES
    return reinterpret_cast<VkImage>(
        static_cast<std::uintptr_t>(value));
#else
    return static_cast<VkImage>(value);
#endif
}

// This function never waits: callers either own an unsubmitted partial state,
// or have already waited for all submitted work to finish.
static void destroy_depth_overlay_resources(
    const DeviceData& data, const DepthOverlayFns& f, DepthOverlayState& st) {
    if (f.destroyCommandPool &&
        st.commandPool != VkCommandPool{}) {
        f.destroyCommandPool(
            data.device,
            st.commandPool,
            nullptr);
    }

    if (f.destroyFramebuffer) {
        for (VkFramebuffer fb : st.framebuffers) {
            if (fb != VkFramebuffer{})
                f.destroyFramebuffer(data.device, fb, nullptr);
        }
    }

    if (f.destroyImageView) {
        for (VkImageView view : st.colorViews) {
            if (view != VkImageView{})
                f.destroyImageView(data.device, view, nullptr);
        }
    }

    if (f.destroyPipeline &&
        st.pipeline != VkPipeline{}) {
        f.destroyPipeline(
            data.device,
            st.pipeline,
            nullptr);
    }

    if (f.destroyRenderPass &&
        st.renderPass != VkRenderPass{}) {
        f.destroyRenderPass(
            data.device,
            st.renderPass,
            nullptr);
    }

    if (f.destroyDescriptorPool &&
        st.descriptorPool != VkDescriptorPool{}) {
        f.destroyDescriptorPool(
            data.device,
            st.descriptorPool,
            nullptr);
    }

    if (f.destroyPipelineLayout &&
        st.pipelineLayout != VkPipelineLayout{}) {
        f.destroyPipelineLayout(
            data.device,
            st.pipelineLayout,
            nullptr);
    }

    if (f.destroyDescriptorSetLayout &&
        st.descriptorSetLayout != VkDescriptorSetLayout{}) {
        f.destroyDescriptorSetLayout(
            data.device,
            st.descriptorSetLayout,
            nullptr);
    }

    if (f.destroySampler &&
        st.sampler != VkSampler{}) {
        f.destroySampler(
            data.device,
            st.sampler,
            nullptr);
    }

    st = DepthOverlayState{};
}

struct OverlayConstructionGuard {
    const DeviceData& data;
    const DepthOverlayFns& f;
    DepthOverlayState& state;
    bool committed = false;
    ~OverlayConstructionGuard() {
        if (!committed) {
            destroy_depth_overlay_resources(data, f, state);
            log_line("[DEPTH-OVERLAY-ROLLBACK] partial resources released");
        }
    }
};

// Command buffers come from a RESET_COMMAND_BUFFER pool. vkBeginCommandBuffer
// implicitly resets an old recording; the submit policy waits before calling us.
bool record_depth_overlay_commands(const DepthOverlayFns& f, const DepthOverlayState& st,
                                   uint32_t imageIndex, const HeartbeatConstants& heartbeat) {
    const size_t i = imageIndex;
    if (i >= st.commandBuffers.size() || i >= st.colorImages.size() || i >= st.framebuffers.size())
        return false;
    VkCommandBuffer cmd = st.commandBuffers[i];
    VkCommandBufferBeginInfo bi{};
    bi.sType =
        VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    bi.flags =
        VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;

    VkResult r =
        f.beginCommandBuffer(cmd, &bi);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkBeginCommandBuffer result=" + std::to_string(r));
        return false;
    }

    VkImageMemoryBarrier depthBarrier{};
    depthBarrier.sType =
        VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    depthBarrier.srcAccessMask =
        VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT |
        VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT;
    depthBarrier.dstAccessMask =
        VK_ACCESS_SHADER_READ_BIT;
    depthBarrier.oldLayout = VK_IMAGE_LAYOUT_GENERAL;
    depthBarrier.newLayout = VK_IMAGE_LAYOUT_GENERAL;
    depthBarrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    depthBarrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    depthBarrier.image = st.depthImage;
    // The current selector only admits D24S8. Include both aspects so this
    // barrier is legal even without separateDepthStencilLayouts; the sampled
    // image view remains DEPTH-only. Both aspects stay in GENERAL.
    depthBarrier.subresourceRange.aspectMask =
        VK_IMAGE_ASPECT_DEPTH_BIT | VK_IMAGE_ASPECT_STENCIL_BIT;
    depthBarrier.subresourceRange.baseMipLevel = 0;
    depthBarrier.subresourceRange.levelCount = 1;
    depthBarrier.subresourceRange.baseArrayLayer = 0;
    depthBarrier.subresourceRange.layerCount = 1;

    f.cmdPipelineBarrier(
        cmd,
        VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT |
        VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT,
        VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
        0,
        0, nullptr,
        0, nullptr,
        1, &depthBarrier);

    VkImageSubresourceRange colorRange{};
    colorRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    colorRange.baseMipLevel = 0;
    colorRange.levelCount = 1;
    colorRange.baseArrayLayer = 0;
    colorRange.layerCount = 1;

    VkImageMemoryBarrier toColor{};
    toColor.sType =
        VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    toColor.srcAccessMask = VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT;
    // LOAD and destination blending read the game's existing color values.
    toColor.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_READ_BIT |
        VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    toColor.oldLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    toColor.newLayout =
        VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    toColor.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toColor.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toColor.image = st.colorImages[i];
    toColor.subresourceRange = colorRange;

    f.cmdPipelineBarrier(
        cmd,
        VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        0,
        0, nullptr,
        0, nullptr,
        1, &toColor);

    VkRenderPassBeginInfo rbi{};
    rbi.sType =
        VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    rbi.renderPass = st.renderPass;
    rbi.framebuffer = st.framebuffers[i];
    rbi.renderArea.offset = {0, 0};
    rbi.renderArea.extent = {st.width, st.height};

    f.cmdBeginRenderPass(
        cmd,
        &rbi,
        VK_SUBPASS_CONTENTS_INLINE);

    f.cmdBindPipeline(
        cmd,
        VK_PIPELINE_BIND_POINT_GRAPHICS,
        st.pipeline);

    f.cmdBindDescriptorSets(
        cmd,
        VK_PIPELINE_BIND_POINT_GRAPHICS,
        st.pipelineLayout,
        0,
        1,
        &st.descriptorSet,
        0,
        nullptr);

    f.cmdPushConstants(cmd, st.pipelineLayout, VK_SHADER_STAGE_FRAGMENT_BIT,
                       0, sizeof(heartbeat), &heartbeat);
    f.cmdDraw(cmd, 3, 1, 0, 0);
    f.cmdEndRenderPass(cmd);

    VkImageMemoryBarrier toPresent{};
    toPresent.sType =
        VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    toPresent.srcAccessMask =
        VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    toPresent.dstAccessMask = 0;
    toPresent.oldLayout =
        VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    toPresent.newLayout =
        VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    toPresent.srcQueueFamilyIndex =
        VK_QUEUE_FAMILY_IGNORED;
    toPresent.dstQueueFamilyIndex =
        VK_QUEUE_FAMILY_IGNORED;
    toPresent.image = st.colorImages[i];
    toPresent.subresourceRange = colorRange;

    f.cmdPipelineBarrier(
        cmd,
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
        0,
        0, nullptr,
        0, nullptr,
        1, &toPresent);

    r =
        f.endCommandBuffer(cmd);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkEndCommandBuffer");
        return false;
    }
    return true;
}

bool create_depth_overlay_state(
    const DeviceData& data,
    VkSwapchainKHR swapchain,
    DepthOverlayState& outState) {

    const DepthOverlayFns f =
        load_depth_overlay_fns(data);

    if (!depth_overlay_fns_ok(f)) {
        log_line("[DEPTH-OVERLAY-ERROR] eksik Vulkan function pointer");
        return false;
    }

    SwapchainInfo sc{};
    uint64_t depthImageKey = 0;
    VkImageView depthView = VkImageView{};

    {
        std::lock_guard<std::mutex> lock(g_state_mutex);

        auto sit =
            g_swapchains.find({data.device, swapchain_handle_u64(swapchain)});

        if (sit == g_swapchains.end() ||
            sit->second.images.empty()) {
            return false;
        }

        sc = sit->second;

        const auto dit = std::find_if(g_custom_depth_views.begin(), g_custom_depth_views.end(),
            [&](const auto& item) { return item.first.device == data.device; });
        if (dit == g_custom_depth_views.end())
            return false;
        depthImageKey = dit->first.handle;
        depthView = dit->second;
    }

    if (depthImageKey == 0 ||
        depthView == VkImageView{}) {
        return false;
    }

    DepthOverlayState st{};
    OverlayConstructionGuard rollback{data, f, st};
    st.swapchain = swapchain;
    st.depthImage = depth_image_from_u64(depthImageKey);
    st.depthView = depthView;
    st.width = sc.width;
    st.height = sc.height;
    st.format = sc.format;
    st.colorImages = sc.images;

    VkSamplerCreateInfo samplerInfo{};
    samplerInfo.sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO;
    samplerInfo.magFilter = VK_FILTER_NEAREST;
    samplerInfo.minFilter = VK_FILTER_NEAREST;
    samplerInfo.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
    samplerInfo.addressModeU = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    samplerInfo.addressModeV = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    samplerInfo.addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    samplerInfo.minLod = 0.0f;
    samplerInfo.maxLod = 0.0f;
    samplerInfo.maxAnisotropy = 1.0f;
    samplerInfo.compareEnable = VK_FALSE;

    VkResult r =
        f.createSampler(
            data.device,
            &samplerInfo,
            nullptr,
            &st.sampler);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkCreateSampler");
        return false;
    }

    VkDescriptorSetLayoutBinding binding{};
    binding.binding = 0;
    binding.descriptorType =
        VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    binding.descriptorCount = 1;
    binding.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;

    VkDescriptorSetLayoutCreateInfo dslInfo{};
    dslInfo.sType =
        VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
    dslInfo.bindingCount = 1;
    dslInfo.pBindings = &binding;

    r =
        f.createDescriptorSetLayout(
            data.device,
            &dslInfo,
            nullptr,
            &st.descriptorSetLayout);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkCreateDescriptorSetLayout");
        return false;
    }

    VkPushConstantRange pushRange{};
    pushRange.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    pushRange.offset = 0;
    pushRange.size = sizeof(HeartbeatConstants);

    VkPipelineLayoutCreateInfo plInfo{};
    plInfo.sType =
        VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
    plInfo.setLayoutCount = 1;
    plInfo.pSetLayouts = &st.descriptorSetLayout;
    plInfo.pushConstantRangeCount = 1;
    plInfo.pPushConstantRanges = &pushRange;

    r =
        f.createPipelineLayout(
            data.device,
            &plInfo,
            nullptr,
            &st.pipelineLayout);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkCreatePipelineLayout");
        return false;
    }

    VkDescriptorPoolSize poolSize{};
    poolSize.type =
        VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    poolSize.descriptorCount = 1;

    VkDescriptorPoolCreateInfo dpInfo{};
    dpInfo.sType =
        VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    dpInfo.maxSets = 1;
    dpInfo.poolSizeCount = 1;
    dpInfo.pPoolSizes = &poolSize;

    r =
        f.createDescriptorPool(
            data.device,
            &dpInfo,
            nullptr,
            &st.descriptorPool);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkCreateDescriptorPool");
        return false;
    }

    VkDescriptorSetAllocateInfo dsAlloc{};
    dsAlloc.sType =
        VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
    dsAlloc.descriptorPool = st.descriptorPool;
    dsAlloc.descriptorSetCount = 1;
    dsAlloc.pSetLayouts = &st.descriptorSetLayout;

    r =
        f.allocateDescriptorSets(
            data.device,
            &dsAlloc,
            &st.descriptorSet);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkAllocateDescriptorSets");
        return false;
    }

    VkDescriptorImageInfo imageInfo{};
    imageInfo.sampler = st.sampler;
    imageInfo.imageView = st.depthView;
    imageInfo.imageLayout = VK_IMAGE_LAYOUT_GENERAL;

    VkWriteDescriptorSet write{};
    write.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    write.dstSet = st.descriptorSet;
    write.dstBinding = 0;
    write.descriptorCount = 1;
    write.descriptorType =
        VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    write.pImageInfo = &imageInfo;

    f.updateDescriptorSets(
        data.device,
        1,
        &write,
        0,
        nullptr);

    VkAttachmentDescription attachment{};
    attachment.format = st.format;
    attachment.samples = VK_SAMPLE_COUNT_1_BIT;
    attachment.loadOp = VK_ATTACHMENT_LOAD_OP_LOAD;
    attachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    attachment.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    attachment.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    attachment.initialLayout =
        VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    attachment.finalLayout =
        VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkAttachmentReference colorRef{};
    colorRef.attachment = 0;
    colorRef.layout =
        VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkSubpassDescription subpass{};
    subpass.pipelineBindPoint =
        VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachmentCount = 1;
    subpass.pColorAttachments = &colorRef;

    VkRenderPassCreateInfo rpInfo{};
    rpInfo.sType =
        VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    rpInfo.attachmentCount = 1;
    rpInfo.pAttachments = &attachment;
    rpInfo.subpassCount = 1;
    rpInfo.pSubpasses = &subpass;

    r =
        f.createRenderPass(
            data.device,
            &rpInfo,
            nullptr,
            &st.renderPass);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkCreateRenderPass");
        return false;
    }

    const std::string dir = depth_shader_dir();

    const auto vertCode =
        read_spirv_file(dir + "/depth.vert.spv");

    const auto fragCode =
        read_spirv_file(dir + "/depth.frag.spv");

    if (vertCode.empty() ||
        fragCode.empty()) {
        log_line(
            "[DEPTH-OVERLAY-ERROR] SPIR-V dosyalari okunamadi dir=" +
            dir);
        return false;
    }

    VkShaderModuleCreateInfo smInfo{};
    smInfo.sType =
        VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;

    VkShaderModule vert = VkShaderModule{};
    VkShaderModule frag = VkShaderModule{};

    smInfo.codeSize =
        vertCode.size() * sizeof(uint32_t);
    smInfo.pCode = vertCode.data();

    r =
        f.createShaderModule(
            data.device,
            &smInfo,
            nullptr,
            &vert);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vertex shader module");
        return false;
    }

    smInfo.codeSize =
        fragCode.size() * sizeof(uint32_t);
    smInfo.pCode = fragCode.data();

    r =
        f.createShaderModule(
            data.device,
            &smInfo,
            nullptr,
            &frag);

    if (r != VK_SUCCESS) {
        f.destroyShaderModule(
            data.device,
            vert,
            nullptr);

        log_line("[DEPTH-OVERLAY-ERROR] fragment shader module");
        return false;
    }

    VkPipelineShaderStageCreateInfo stages[2]{};

    stages[0].sType =
        VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    stages[0].stage = VK_SHADER_STAGE_VERTEX_BIT;
    stages[0].module = vert;
    stages[0].pName = "main";

    stages[1].sType =
        VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    stages[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    stages[1].module = frag;
    stages[1].pName = "main";

    VkPipelineVertexInputStateCreateInfo vi{};
    vi.sType =
        VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;

    VkPipelineInputAssemblyStateCreateInfo ia{};
    ia.sType =
        VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;

    VkViewport viewport{};
    viewport.x = 0.0f;
    viewport.y = 0.0f;
    viewport.width = static_cast<float>(st.width);
    viewport.height = static_cast<float>(st.height);
    viewport.minDepth = 0.0f;
    viewport.maxDepth = 1.0f;

    VkRect2D scissor{};
    scissor.offset = {0, 0};
    scissor.extent = {st.width, st.height};

    VkPipelineViewportStateCreateInfo vp{};
    vp.sType =
        VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
    vp.viewportCount = 1;
    vp.pViewports = &viewport;
    vp.scissorCount = 1;
    vp.pScissors = &scissor;

    VkPipelineRasterizationStateCreateInfo rs{};
    rs.sType =
        VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
    rs.polygonMode = VK_POLYGON_MODE_FILL;
    rs.cullMode = VK_CULL_MODE_NONE;
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rs.lineWidth = 1.0f;

    VkPipelineMultisampleStateCreateInfo ms{};
    ms.sType =
        VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;

    VkPipelineColorBlendAttachmentState cba{};

    cba.blendEnable = VK_TRUE;

    cba.srcColorBlendFactor =
        VK_BLEND_FACTOR_SRC_ALPHA;

    cba.dstColorBlendFactor =
        VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;

    cba.colorBlendOp =
        VK_BLEND_OP_ADD;

    cba.srcAlphaBlendFactor =
        VK_BLEND_FACTOR_ONE;

    cba.dstAlphaBlendFactor =
        VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;

    cba.alphaBlendOp =
        VK_BLEND_OP_ADD;

    cba.colorWriteMask =
        VK_COLOR_COMPONENT_R_BIT |
        VK_COLOR_COMPONENT_G_BIT |
        VK_COLOR_COMPONENT_B_BIT |
        VK_COLOR_COMPONENT_A_BIT;

    VkPipelineColorBlendStateCreateInfo cb{};
    cb.sType =
        VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
    cb.attachmentCount = 1;
    cb.pAttachments = &cba;

    VkGraphicsPipelineCreateInfo gp{};
    gp.sType =
        VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
    gp.stageCount = 2;
    gp.pStages = stages;
    gp.pVertexInputState = &vi;
    gp.pInputAssemblyState = &ia;
    gp.pViewportState = &vp;
    gp.pRasterizationState = &rs;
    gp.pMultisampleState = &ms;
    gp.pColorBlendState = &cb;
    gp.layout = st.pipelineLayout;
    gp.renderPass = st.renderPass;
    gp.subpass = 0;

    r =
        f.createGraphicsPipelines(
            data.device,
            VkPipelineCache{},
            1,
            &gp,
            nullptr,
            &st.pipeline);

    f.destroyShaderModule(
        data.device,
        vert,
        nullptr);

    f.destroyShaderModule(
        data.device,
        frag,
        nullptr);

    if (r != VK_SUCCESS) {
        std::ostringstream os;
        os << "[DEPTH-OVERLAY-ERROR] vkCreateGraphicsPipelines result="
           << static_cast<int>(r);
        log_line(os.str());
        return false;
    }

    st.colorViews.resize(sc.images.size());
    st.framebuffers.resize(sc.images.size());

    for (size_t i = 0; i < sc.images.size(); ++i) {
        VkImageViewCreateInfo iv{};
        iv.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        iv.image = sc.images[i];
        iv.viewType = VK_IMAGE_VIEW_TYPE_2D;
        iv.format = st.format;
        iv.components.r = VK_COMPONENT_SWIZZLE_IDENTITY;
        iv.components.g = VK_COMPONENT_SWIZZLE_IDENTITY;
        iv.components.b = VK_COMPONENT_SWIZZLE_IDENTITY;
        iv.components.a = VK_COMPONENT_SWIZZLE_IDENTITY;
        iv.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        iv.subresourceRange.baseMipLevel = 0;
        iv.subresourceRange.levelCount = 1;
        iv.subresourceRange.baseArrayLayer = 0;
        iv.subresourceRange.layerCount = 1;

        r =
            f.createImageView(
                data.device,
                &iv,
                nullptr,
                &st.colorViews[i]);

        if (r != VK_SUCCESS) {
            log_line("[DEPTH-OVERLAY-ERROR] swapchain vkCreateImageView");
            return false;
        }

        VkFramebufferCreateInfo fb{};
        fb.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
        fb.renderPass = st.renderPass;
        fb.attachmentCount = 1;
        fb.pAttachments = &st.colorViews[i];
        fb.width = st.width;
        fb.height = st.height;
        fb.layers = 1;

        r =
            f.createFramebuffer(
                data.device,
                &fb,
                nullptr,
                &st.framebuffers[i]);

        if (r != VK_SUCCESS) {
            log_line("[DEPTH-OVERLAY-ERROR] vkCreateFramebuffer");
            return false;
        }
    }

    VkCommandPoolCreateInfo cp{};
    cp.sType =
        VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    cp.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    cp.queueFamilyIndex = 0;

    r =
        f.createCommandPool(
            data.device,
            &cp,
            nullptr,
            &st.commandPool);

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkCreateCommandPool");
        return false;
    }

    st.commandBuffers.resize(sc.images.size());

    VkCommandBufferAllocateInfo ca{};
    ca.sType =
        VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    ca.commandPool = st.commandPool;
    ca.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ca.commandBufferCount =
        static_cast<uint32_t>(st.commandBuffers.size());

    r =
        f.allocateCommandBuffers(
            data.device,
            &ca,
            st.commandBuffers.data());

    if (r != VK_SUCCESS) {
        log_line("[DEPTH-OVERLAY-ERROR] vkAllocateCommandBuffers");
        return false;
    }

    for (VkCommandBuffer cmd : st.commandBuffers) {
        if (!initialize_layer_command_buffer(data, cmd))
            return false;
    }

    outState = std::move(st);
    rollback.committed = true;

    std::ostringstream ready;
    ready
        << "[DEPTH-OVERLAY-READY]"
        << " extent=" << outState.width << "x" << outState.height
        << " format=" << static_cast<int>(outState.format)
        << " images=" << outState.commandBuffers.size()
        << " depthImage=0x" << std::hex << depthImageKey
        << " depthView=0x"
        << image_view_handle_u64(outState.depthView)
        << std::dec;

    log_line(ready.str());

    return true;
}


void destroy_depth_overlay_state(
    const DeviceData& data,
    VkSwapchainKHR swapchain) {

    const uint64_t key =
        swapchain_handle_u64(swapchain);

    DepthOverlayState st{};
    bool found = false;

    {
        std::lock_guard<std::mutex> lock(g_state_mutex);

        auto it =
            g_depth_overlay_states.find({data.device, key});

        if (it != g_depth_overlay_states.end()) {
            st = std::move(it->second);
            g_depth_overlay_states.erase(it);
            found = true;
        }
    }

    if (!found)
        return;

    const DepthOverlayFns f =
        load_depth_overlay_fns(data);

    if (f.deviceWaitIdle)
        f.deviceWaitIdle(data.device);

    destroy_depth_overlay_resources(data, f, st);

    std::ostringstream os;
    os << "[DEPTH-OVERLAY-DESTROY]"
       << " swapchain=0x"
       << std::hex << key << std::dec;

    log_line(os.str());
}

bool depth_overlay_present(
    const DeviceData& data,
    VkQueue queue,
    const VkPresentInfoKHR* presentInfo,
    uint64_t frame) {

    if (!presentInfo ||
        presentInfo->swapchainCount == 0 ||
        !presentInfo->pImageIndices) {
        return false;
    }

    const VkSwapchainKHR swapchain =
        presentInfo->pSwapchains[0];

    const uint64_t scKey =
        swapchain_handle_u64(swapchain);

    bool needCreate = false;

    {
        std::lock_guard<std::mutex> lock(g_state_mutex);

        needCreate =
            g_depth_overlay_states.find({data.device, scKey}) ==
            g_depth_overlay_states.end();
    }

    if (needCreate) {
        DepthOverlayState newState{};

        if (!create_depth_overlay_state(
                data,
                swapchain,
                newState)) {
            return false;
        }

        bool inserted;
        {
            std::lock_guard<std::mutex> lock(g_state_mutex);
            inserted = g_depth_overlay_states.try_emplace(
                DeviceHandleKey{data.device, scKey}, std::move(newState)).second;
        }
        if (!inserted) {
            const auto f = load_depth_overlay_fns(data);
            destroy_depth_overlay_resources(data, f, newState);
        }
    }

    DepthOverlayState state{};

    {
        std::lock_guard<std::mutex> lock(g_state_mutex);

        auto it =
            g_depth_overlay_states.find({data.device, scKey});

        if (it == g_depth_overlay_states.end())
            return false;

        state = it->second;
    }

    const uint32_t imageIndex =
        presentInfo->pImageIndices[0];

    if (imageIndex >= state.commandBuffers.size())
        return false;

    const DepthOverlayFns f =
        load_depth_overlay_fns(data);

    const auto heartbeat = current_heartbeat(state.width, state.height);
    if (!submit_depth_overlay_debug(f, queue, state, imageIndex, heartbeat))
        return false;

    if (frame <= 10 ||
        frame % 120 == 0) {

        std::ostringstream os;
        os << "[DEPTH-DRAW]"
           << " frame=" << frame
           << " imageIndex=" << imageIndex;

        log_line(os.str());
    }

    return true;
}

void destroy_depth_overlays_for_image(const DeviceData& data, VkImage image) {
    std::vector<VkSwapchainKHR> swapchains;
    {
        std::lock_guard<std::mutex> lock(g_state_mutex);
        for (const auto& [key, state] : g_depth_overlay_states) {
            if (key.device == data.device && state.depthImage == image)
                swapchains.push_back(state.swapchain);
        }
    }
    for (VkSwapchainKHR swapchain : swapchains)
        destroy_depth_overlay_state(data, swapchain);
}

void destroy_device_depth_overlays(const DeviceData& data) {
    std::vector<VkSwapchainKHR> swapchains;
    {
        std::lock_guard<std::mutex> lock(g_state_mutex);
        for (const auto& [key, state] : g_depth_overlay_states) {
            if (key.device == data.device)
                swapchains.push_back(state.swapchain);
        }
    }
    for (VkSwapchainKHR swapchain : swapchains)
        destroy_depth_overlay_state(data, swapchain);
}

} // namespace depth_probe
