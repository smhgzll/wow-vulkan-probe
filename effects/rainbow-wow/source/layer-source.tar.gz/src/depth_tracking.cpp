#include "layer_state.hpp"
#include "overlay_renderer.hpp"
#include "depth_tracking.hpp"

using namespace depth_probe;

extern "C" {

LAYER_EXPORT VKAPI_ATTR VkResult VKAPI_CALL vkCreateImage(
    VkDevice device,
    const VkImageCreateInfo* pCreateInfo,
    const VkAllocationCallbacks* pAllocator,
    VkImage* pImage) {

    auto data = get_device_data(device);
    if (!data || !data->next_create_image) {
        return VK_ERROR_INITIALIZATION_FAILED;
    }

    VkImageCreateInfo patchedCreateInfo{};
    const VkImageCreateInfo* createInfoToUse = pCreateInfo;
    bool patchedDepth = false;

    if (pCreateInfo &&
        pCreateInfo->extent.width == 1920 &&
        pCreateInfo->extent.height == 1080 &&
        pCreateInfo->extent.depth == 1 &&
        pCreateInfo->format == VK_FORMAT_D24_UNORM_S8_UINT &&
        pCreateInfo->samples == VK_SAMPLE_COUNT_1_BIT &&
        (pCreateInfo->usage & VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT)) {

        patchedCreateInfo = *pCreateInfo;
        patchedCreateInfo.usage |= VK_IMAGE_USAGE_SAMPLED_BIT;

        createInfoToUse = &patchedCreateInfo;
        patchedDepth = true;
    }

    VkResult result = data->next_create_image(
        device, createInfoToUse, pAllocator, pImage);

    // Eğer GPU bu kombinasyonu desteklemiyorsa oyunu bozma:
    // orijinal VkImageCreateInfo ile tekrar dene.
    if (result != VK_SUCCESS && patchedDepth) {
        std::ostringstream os;
        os << "[PATCH-FAILED] sampled depth creation failed result="
           << result << " - retrying original";
        log_line(os.str());

        result = data->next_create_image(
            device, pCreateInfo, pAllocator, pImage);

        patchedDepth = false;
    }

    if (result != VK_SUCCESS || !pCreateInfo) {
        return result;
    }

    if (patchedDepth) {
        std::ostringstream os;
        os << "[PATCHED-DEPTH] "
           << pCreateInfo->extent.width << "x"
           << pCreateInfo->extent.height
           << " format=VK_FORMAT_D24_UNORM_S8_UINT"
           << " samples=1"
           << " oldUsage=" << usage_string(pCreateInfo->usage)
           << " newUsage=" << usage_string(createInfoToUse->usage);

        log_line(os.str());

        if (pImage && *pImage) {
            std::lock_guard<std::mutex> lock(g_state_mutex);
            g_target_depth_images.insert(
                {device, image_handle_u64(*pImage)});
        }
    }

    const bool depthUsage =
        (pCreateInfo->usage & VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT) != 0;
    const bool depthFormat = is_depth_or_stencil_format(pCreateInfo->format);

    if (depthUsage || depthFormat || log_all_images()) {
        std::ostringstream os;

        if (depthUsage || depthFormat) {
            os << "[DEPTH-CANDIDATE] ";
        } else {
            os << "[image] ";
        }

        const char* fmtName = format_name(pCreateInfo->format);

        os << pCreateInfo->extent.width << 'x'
           << pCreateInfo->extent.height << 'x'
           << pCreateInfo->extent.depth
           << " format=" << (fmtName ? fmtName : "other")
           << "(" << static_cast<int>(pCreateInfo->format) << ")"
           << " usage=" << usage_string(pCreateInfo->usage)
           << " samples=" << sample_count_string(pCreateInfo->samples)
           << " mips=" << pCreateInfo->mipLevels
           << " layers=" << pCreateInfo->arrayLayers
           << " tiling=" << (pCreateInfo->tiling == VK_IMAGE_TILING_OPTIMAL ? "OPTIMAL" : "LINEAR");

#if VK_USE_64_BIT_PTR_DEFINES
        if (pImage && *pImage) {
            os << " image=0x"
               << std::hex
               << reinterpret_cast<std::uintptr_t>(*pImage)
               << std::dec;
        }
#endif

        log_line(os.str());
    }

    return result;
}

LAYER_EXPORT VKAPI_ATTR VkResult VKAPI_CALL vkCreateImageView(
    VkDevice device,
    const VkImageViewCreateInfo* pCreateInfo,
    const VkAllocationCallbacks* pAllocator,
    VkImageView* pView) {

    auto data = get_device_data(device);

    if (!data || !data->next_create_image_view) {
        return VK_ERROR_INITIALIZATION_FAILED;
    }

    VkResult result = data->next_create_image_view(
        device, pCreateInfo, pAllocator, pView);

    if (result != VK_SUCCESS || !pCreateInfo) {
        return result;
    }

    bool isTarget = false;

    {
        std::lock_guard<std::mutex> lock(g_state_mutex);

        isTarget =
            g_target_depth_images.count(
                {device, image_handle_u64(pCreateInfo->image)}) != 0;
    }

    if (isTarget) {
        const uint64_t imageKey =
            image_handle_u64(pCreateInfo->image);

        bool customViewAlreadyExists = false;

        {
            std::lock_guard<std::mutex> lock(g_state_mutex);
            customViewAlreadyExists =
                g_custom_depth_views.find({device, imageKey}) !=
                g_custom_depth_views.end();
        }

        if (!customViewAlreadyExists && data->next_destroy_image_view) {
            VkImageViewCreateInfo depthViewInfo = *pCreateInfo;

            // Biz descriptor'da depth okuyacağız.
            // Orijinal view DEPTH|STENCIL; bizimki yalnız DEPTH.
            depthViewInfo.pNext = nullptr;
            depthViewInfo.subresourceRange.aspectMask =
                VK_IMAGE_ASPECT_DEPTH_BIT;

            VkImageView customDepthView = VK_NULL_HANDLE;

            VkResult customResult =
                data->next_create_image_view(
                    device,
                    &depthViewInfo,
                    nullptr,
                    &customDepthView);

            if (customResult == VK_SUCCESS) {
                {
                    std::lock_guard<std::mutex> lock(g_state_mutex);
                    const auto [it, inserted] = g_custom_depth_views.emplace(
                        DeviceHandleKey{device, imageKey}, customDepthView);
                    if (!inserted) {
                        // Concurrent view creation may have won the race.
                        data->next_destroy_image_view(device, customDepthView, nullptr);
                        customDepthView = it->second;
                    }
                }

                std::ostringstream customLog;

                customLog
                    << "[CUSTOM-DEPTH-VIEW]"
                    << " image=0x"
                    << std::hex
                    << imageKey
                    << " view=0x"
                    << image_view_handle_u64(customDepthView)
                    << std::dec
                    << " format="
                    << static_cast<int>(depthViewInfo.format)
                    << " aspect="
                    << aspect_string(
                        depthViewInfo.subresourceRange.aspectMask);

                log_line(customLog.str());
            } else {
                std::ostringstream errorLog;

                errorLog
                    << "[CUSTOM-DEPTH-VIEW-FAILED]"
                    << " result="
                    << static_cast<int>(customResult);

                log_line(errorLog.str());
            }
        }

        std::ostringstream os;

        os << "[TARGET-DEPTH-VIEW]"
           << " image=0x"
           << std::hex
           << image_handle_u64(pCreateInfo->image)
           << " view=0x"
           << image_view_handle_u64(*pView)
           << std::dec
           << " format="
           << static_cast<int>(pCreateInfo->format)
           << " viewType="
           << static_cast<int>(pCreateInfo->viewType)
           << " aspect="
           << aspect_string(
                pCreateInfo->subresourceRange.aspectMask)
           << " baseMip="
           << pCreateInfo->subresourceRange.baseMipLevel
           << " levels="
           << pCreateInfo->subresourceRange.levelCount
           << " baseLayer="
           << pCreateInfo->subresourceRange.baseArrayLayer
           << " layers="
           << pCreateInfo->subresourceRange.layerCount;

        log_line(os.str());
    }

    return result;
}

LAYER_EXPORT VKAPI_ATTR void VKAPI_CALL vkCmdPipelineBarrier(
    VkCommandBuffer commandBuffer,
    VkPipelineStageFlags srcStageMask,
    VkPipelineStageFlags dstStageMask,
    VkDependencyFlags dependencyFlags,
    uint32_t memoryBarrierCount,
    const VkMemoryBarrier* pMemoryBarriers,
    uint32_t bufferMemoryBarrierCount,
    const VkBufferMemoryBarrier* pBufferMemoryBarriers,
    uint32_t imageMemoryBarrierCount,
    const VkImageMemoryBarrier* pImageMemoryBarriers) {

    auto data = get_device_data(
        reinterpret_cast<VkDevice>(commandBuffer));

    // command buffer ile device ayni dispatch table'i kullanir;
    // normal lookup olmazsa dogrudan dispatch key ile dene.
    if (!data) {
        std::lock_guard<std::mutex> lock(g_state_mutex);
        auto it = g_devices.find(dispatch_key(commandBuffer));
        if (it != g_devices.end())
            data = it->second;
    }

    for (uint32_t i = 0; i < imageMemoryBarrierCount; ++i) {
        const auto& b = pImageMemoryBarriers[i];

        if (data && is_target_depth(data->device, b.image)) {
            std::ostringstream os;
            os << "[DEPTH-BARRIER]"
               << " old=" << layout_name(b.oldLayout)
               << "(" << static_cast<int>(b.oldLayout) << ")"
               << " new=" << layout_name(b.newLayout)
               << "(" << static_cast<int>(b.newLayout) << ")"
               << " aspect="
               << aspect_string(b.subresourceRange.aspectMask);

            log_line(os.str());
        }
    }

    if (data && data->next_cmd_pipeline_barrier) {
        data->next_cmd_pipeline_barrier(
            commandBuffer,
            srcStageMask,
            dstStageMask,
            dependencyFlags,
            memoryBarrierCount,
            pMemoryBarriers,
            bufferMemoryBarrierCount,
            pBufferMemoryBarriers,
            imageMemoryBarrierCount,
            pImageMemoryBarriers);
    }
}

LAYER_EXPORT VKAPI_ATTR void VKAPI_CALL vkCmdPipelineBarrier2(
    VkCommandBuffer commandBuffer,
    const VkDependencyInfo* pDependencyInfo) {

    std::optional<DeviceData> data;

    {
        std::lock_guard<std::mutex> lock(g_state_mutex);
        auto it = g_devices.find(dispatch_key(commandBuffer));
        if (it != g_devices.end())
            data = it->second;
    }

    if (pDependencyInfo) {
        for (uint32_t i = 0;
             i < pDependencyInfo->imageMemoryBarrierCount;
             ++i) {

            const auto& b =
                pDependencyInfo->pImageMemoryBarriers[i];

            if (data && is_target_depth(data->device, b.image)) {
                std::ostringstream os;

                os << "[DEPTH-BARRIER2]"
                   << " old=" << layout_name(b.oldLayout)
                   << "(" << static_cast<int>(b.oldLayout) << ")"
                   << " new=" << layout_name(b.newLayout)
                   << "(" << static_cast<int>(b.newLayout) << ")"
                   << " aspect="
                   << aspect_string(
                          b.subresourceRange.aspectMask);

                log_line(os.str());
            }
        }
    }

    if (data && data->next_cmd_pipeline_barrier2)
        data->next_cmd_pipeline_barrier2(
            commandBuffer,
            pDependencyInfo);
}

LAYER_EXPORT VKAPI_ATTR void VKAPI_CALL vkDestroyImage(
    VkDevice device, VkImage image, const VkAllocationCallbacks* pAllocator) {
    auto data = get_device_data(device);
    if (!data || !data->next_destroy_image) return;

    if (is_target_depth(device, image)) {
        // Retire descriptors/recorded commands before the borrowed image dies.
        destroy_depth_overlays_for_image(*data, image);
        VkImageView view{};
        {
            std::lock_guard<std::mutex> lock(g_state_mutex);
            const DeviceHandleKey key{device, image_handle_u64(image)};
            auto it = g_custom_depth_views.find(key);
            if (it != g_custom_depth_views.end()) {
                view = it->second;
                g_custom_depth_views.erase(it);
            }
            g_target_depth_images.erase(key);
        }
        if (view != VkImageView{} && data->next_destroy_image_view)
            data->next_destroy_image_view(device, view, nullptr);
        log_line("[DEPTH-DESTROY] retired image tracking and custom view");
    }
    data->next_destroy_image(device, image, pAllocator);
}

} // extern "C"

namespace depth_probe {
void destroy_device_depth_views(const DeviceData& data) {
    std::vector<VkImageView> views;
    {
        std::lock_guard<std::mutex> lock(g_state_mutex);
        for (auto it = g_custom_depth_views.begin(); it != g_custom_depth_views.end();) {
            if (it->first.device == data.device) {
                views.push_back(it->second);
                it = g_custom_depth_views.erase(it);
            } else {
                ++it;
            }
        }
        std::erase_if(g_target_depth_images, [&](const auto& key) {
            return key.device == data.device;
        });
    }
    for (VkImageView view : views) {
        if (data.next_destroy_image_view)
            data.next_destroy_image_view(data.device, view, nullptr);
    }
    if (!views.empty())
        log_line("[DEPTH-DEVICE-CLEANUP] custom views=" + std::to_string(views.size()));
}
} // namespace depth_probe
