#include "overlay_internal.hpp"

namespace depth_probe {

template <typename T>
T overlay_load(const DeviceData& data, const char* name) {
    if (!data.next_gdpa || data.device == VkDevice{})
        return nullptr;

    return reinterpret_cast<T>(
        data.next_gdpa(data.device, name));
}

DepthOverlayFns load_depth_overlay_fns(const DeviceData& data) {
    DepthOverlayFns f{};

    f.createSampler = overlay_load<PFN_vkCreateSampler>(data, "vkCreateSampler");
    f.destroySampler = overlay_load<PFN_vkDestroySampler>(data, "vkDestroySampler");
    f.createDescriptorSetLayout = overlay_load<PFN_vkCreateDescriptorSetLayout>(data, "vkCreateDescriptorSetLayout");
    f.destroyDescriptorSetLayout = overlay_load<PFN_vkDestroyDescriptorSetLayout>(data, "vkDestroyDescriptorSetLayout");
    f.createPipelineLayout = overlay_load<PFN_vkCreatePipelineLayout>(data, "vkCreatePipelineLayout");
    f.destroyPipelineLayout = overlay_load<PFN_vkDestroyPipelineLayout>(data, "vkDestroyPipelineLayout");
    f.createRenderPass = overlay_load<PFN_vkCreateRenderPass>(data, "vkCreateRenderPass");
    f.destroyRenderPass = overlay_load<PFN_vkDestroyRenderPass>(data, "vkDestroyRenderPass");
    f.createShaderModule = overlay_load<PFN_vkCreateShaderModule>(data, "vkCreateShaderModule");
    f.destroyShaderModule = overlay_load<PFN_vkDestroyShaderModule>(data, "vkDestroyShaderModule");
    f.createGraphicsPipelines = overlay_load<PFN_vkCreateGraphicsPipelines>(data, "vkCreateGraphicsPipelines");
    f.destroyPipeline = overlay_load<PFN_vkDestroyPipeline>(data, "vkDestroyPipeline");
    f.createDescriptorPool = overlay_load<PFN_vkCreateDescriptorPool>(data, "vkCreateDescriptorPool");
    f.destroyDescriptorPool = overlay_load<PFN_vkDestroyDescriptorPool>(data, "vkDestroyDescriptorPool");
    f.allocateDescriptorSets = overlay_load<PFN_vkAllocateDescriptorSets>(data, "vkAllocateDescriptorSets");
    f.updateDescriptorSets = overlay_load<PFN_vkUpdateDescriptorSets>(data, "vkUpdateDescriptorSets");
    f.createImageView = overlay_load<PFN_vkCreateImageView>(data, "vkCreateImageView");
    f.destroyImageView = overlay_load<PFN_vkDestroyImageView>(data, "vkDestroyImageView");
    f.createFramebuffer = overlay_load<PFN_vkCreateFramebuffer>(data, "vkCreateFramebuffer");
    f.destroyFramebuffer = overlay_load<PFN_vkDestroyFramebuffer>(data, "vkDestroyFramebuffer");
    f.createCommandPool = overlay_load<PFN_vkCreateCommandPool>(data, "vkCreateCommandPool");
    f.destroyCommandPool = overlay_load<PFN_vkDestroyCommandPool>(data, "vkDestroyCommandPool");
    f.allocateCommandBuffers = overlay_load<PFN_vkAllocateCommandBuffers>(data, "vkAllocateCommandBuffers");
    f.beginCommandBuffer = overlay_load<PFN_vkBeginCommandBuffer>(data, "vkBeginCommandBuffer");
    f.endCommandBuffer = overlay_load<PFN_vkEndCommandBuffer>(data, "vkEndCommandBuffer");
    f.cmdPipelineBarrier = overlay_load<PFN_vkCmdPipelineBarrier>(data, "vkCmdPipelineBarrier");
    f.cmdBeginRenderPass = overlay_load<PFN_vkCmdBeginRenderPass>(data, "vkCmdBeginRenderPass");
    f.cmdEndRenderPass = overlay_load<PFN_vkCmdEndRenderPass>(data, "vkCmdEndRenderPass");
    f.cmdBindPipeline = overlay_load<PFN_vkCmdBindPipeline>(data, "vkCmdBindPipeline");
    f.cmdBindDescriptorSets = overlay_load<PFN_vkCmdBindDescriptorSets>(data, "vkCmdBindDescriptorSets");
    f.cmdPushConstants = overlay_load<PFN_vkCmdPushConstants>(data, "vkCmdPushConstants");
    f.cmdDraw = overlay_load<PFN_vkCmdDraw>(data, "vkCmdDraw");
    f.queueSubmit = overlay_load<PFN_vkQueueSubmit>(data, "vkQueueSubmit");
    f.queueWaitIdle = overlay_load<PFN_vkQueueWaitIdle>(data, "vkQueueWaitIdle");
    f.deviceWaitIdle = overlay_load<PFN_vkDeviceWaitIdle>(data, "vkDeviceWaitIdle");

    return f;
}

bool depth_overlay_fns_ok(const DepthOverlayFns& f) {
    return f.destroySampler &&
           f.destroyDescriptorSetLayout &&
           f.destroyPipelineLayout &&
           f.destroyRenderPass &&
           f.destroyPipeline &&
           f.destroyDescriptorPool &&
           f.destroyImageView &&
           f.destroyFramebuffer &&
           f.destroyCommandPool &&
           f.deviceWaitIdle &&
           f.createSampler &&
           f.createDescriptorSetLayout &&
           f.createPipelineLayout &&
           f.createRenderPass &&
           f.createShaderModule &&
           f.destroyShaderModule &&
           f.createGraphicsPipelines &&
           f.createDescriptorPool &&
           f.allocateDescriptorSets &&
           f.updateDescriptorSets &&
           f.createImageView &&
           f.createFramebuffer &&
           f.createCommandPool &&
           f.allocateCommandBuffers &&
           f.beginCommandBuffer &&
           f.endCommandBuffer &&
           f.cmdPipelineBarrier &&
           f.cmdBeginRenderPass &&
           f.cmdEndRenderPass &&
           f.cmdBindPipeline &&
           f.cmdBindDescriptorSets &&
           f.cmdPushConstants &&
           f.cmdDraw &&
           f.queueSubmit &&
           f.queueWaitIdle;
}

} // namespace depth_probe
